Lege hier optional 'alarm.mp3' ab (kurzer, lauter Alarmton).

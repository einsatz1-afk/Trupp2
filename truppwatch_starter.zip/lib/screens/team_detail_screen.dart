import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../app.dart';
import '../models/team.dart';
import '../widgets/firefighter_chip.dart';
import '../services/timer_service.dart';
import '../services/notification_service.dart';
import '../services/export_service.dart';
import 'team_log_screen.dart';

class TeamDetailScreen extends StatefulWidget {
  final String teamId;
  const TeamDetailScreen({super.key, required this.teamId});

  @override
  State<TeamDetailScreen> createState() => _TeamDetailScreenState();
}

class _TeamDetailScreenState extends State<TeamDetailScreen> {
  final Map<String, TimerService> _timers = {};

  @override
  void dispose() {
    for (final t in _timers.values) {
      t.stop();
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final Team team = app.teams.firstWhere((t) => t.id == widget.teamId);

    return Scaffold(
      appBar: AppBar(
        title: Text(team.label),
        actions: [
          IconButton(
            tooltip: 'Logbuch',
            icon: const Icon(Icons.list_alt),
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => TeamLogScreen(teamId: team.id, teamLabel: team.label),
              ),
            ),
          ),
          IconButton(
            tooltip: 'CSV-Export teilen',
            icon: const Icon(Icons.ios_share),
            onPressed: () async {
              await ExportService.shareTeamLog(teamLabel: team.label);
            },
          ),
          IconButton(
            tooltip: 'Testalarm',
            icon: const Icon(Icons.alarm),
            onPressed: () async {
              await NotificationService.showNow(1, team.label, 'Kontaktfälligkeit prüfen');
            },
          )
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(children: [
              const Text('Kontaktintervall (Min): '),
              DropdownButton<int>(
                value: team.contactIntervalMin,
                onChanged: (v) => v!=null ? app.setContactInterval(team.id, v) : null,
                items: const [5,10,15].map((m)=>DropdownMenuItem(value:m, child: Text('$m'))).toList(),
              ),
            ]),
            const SizedBox(height: 12),
            Expanded(
              child: ListView(
                children: team.members.map((m) {
                  _timers.putIfAbsent(m.firefighterId, () {
                    final ts = TimerService(start: m.start, onTick: (_) => setState((){}));
                    ts.startTicker();
                    return ts;
                  });
                  final now = DateTime.now();
                  final elapsed = now.difference(m.start);
                  final base = m.lastContact ?? m.start;
                  final dueAt = base.add(Duration(minutes: team.contactIntervalMin));
                  final overdue = now.isAfter(dueAt);
                  return FirefighterChip(
                    name: app.displayNameFor(m.firefighterId),
                    startPressure: m.startPressureBar,
                    elapsed: elapsed,
                    lastContact: m.lastContact,
                    dueAt: dueAt,
                    overdue: overdue,
                    onTap: () async {
                      app.contactAck(team.id, m.firefighterId, DateTime.now());
                    },
                    onCheckout: () => app.checkOut(team.id, m.firefighterId),
                  );
                }).toList(),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

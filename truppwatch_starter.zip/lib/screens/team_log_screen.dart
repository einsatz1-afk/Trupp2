import 'package:flutter/material.dart';
import '../services/event_log_service.dart';
import '../models/event.dart';

class TeamLogScreen extends StatelessWidget {
  final String teamId;
  final String teamLabel;
  const TeamLogScreen({super.key, required this.teamId, required this.teamLabel});

  IconData _iconFor(EventType t) {
    switch (t) {
      case EventType.checkIn: return Icons.login;
      case EventType.contactAck: return Icons.check_circle;
      case EventType.checkOut: return Icons.logout;
      case EventType.reminderDue: return Icons.alarm_on;
      case EventType.note: return Icons.note_alt;
    }
  }

  @override
  Widget build(BuildContext context) {
    final events = EventLogService.forTeamLabel(teamLabel);
    return Scaffold(
      appBar: AppBar(title: Text('Logbuch – $teamLabel')),
      body: ListView.separated(
        itemCount: events.length,
        separatorBuilder: (_, __) => const Divider(height: 1),
        itemBuilder: (_, i) {
          final e = events[i];
          final who = (e.firefighterName != null && e.firefighterName!.isNotEmpty)
              ? e.firefighterName!
              : (e.firefighterId ?? '');
          return ListTile(
            leading: Icon(_iconFor(e.type)),
            title: Text(e.type.name),
            subtitle: Text('${e.ts} — $who${e.message != null ? ' — ${e.message}' : ''}'),
          );
        },
      ),
    );
  }
}

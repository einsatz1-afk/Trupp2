import 'package:flutter/material.dart';
import '../services/nfc_service.dart';

class NFCProgramScreen extends StatefulWidget {
  const NFCProgramScreen({super.key});

  @override
  State<NFCProgramScreen> createState() => _NFCProgramScreenState();
}

class _NFCProgramScreenState extends State<NFCProgramScreen> {
  final _id = TextEditingController();
  final _name = TextEditingController();
  final _phone = TextEditingController();
  final _emg = TextEditingController();
  String? _status;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('NFC-Tag programmieren')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            TextField(controller: _id, decoration: const InputDecoration(labelText: 'ID (z. B. Badge-Nummer)')),
            TextField(controller: _name, decoration: const InputDecoration(labelText: 'Name')),
            TextField(controller: _phone, decoration: const InputDecoration(labelText: 'Telefon')),
            TextField(controller: _emg, decoration: const InputDecoration(labelText: 'Notfallnummer')),
            const SizedBox(height: 12),
            FilledButton.icon(
              icon: const Icon(Icons.save),
              label: const Text('Auf NFC schreiben'),
              onPressed: () async {
                try {
                  setState(()=>_status='Warte auf Tag…');
                  await NFCService.writeFirefighter({
                    'id': _id.text.trim(),
                    'name': _name.text.trim(),
                    'phone': _phone.text.trim(),
                    'emergencyPhone': _emg.text.trim(),
                  });
                  setState(()=>_status='Erfolgreich geschrieben');
                } catch (e) {
                  setState(()=>_status='Fehler: $e');
                }
              },
            ),
            const SizedBox(height: 8),
            if (_status != null) Text(_status!),
          ],
        ),
      ),
    );
  }
}

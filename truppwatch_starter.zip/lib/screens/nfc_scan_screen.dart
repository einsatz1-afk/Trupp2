import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../app.dart';
import '../models/checkin.dart';
import '../models/firefighter.dart';
import '../services/nfc_service.dart';

class NFCScanScreen extends StatefulWidget {
  final String teamId;
  const NFCScanScreen({super.key, required this.teamId});

  @override
  State<NFCScanScreen> createState() => _NFCScanScreenState();
}

class _NFCScanScreenState extends State<NFCScanScreen> {
  String? _status;
  final _pressureCtrl = TextEditingController();

  Future<void> _showWarnDialog(String title, String msg) async {
    if (!mounted) return;
    await showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: Text(title),
        content: Text(msg),
        actions: [
          TextButton(onPressed: ()=>Navigator.pop(context), child: const Text('OK')),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    return Scaffold(
      appBar: AppBar(title: const Text('NFC Check-in')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(_status ?? 'Tag jetzt scannen und Startdruck erfassen.'),
            const SizedBox(height: 12),
            TextField(
              controller: _pressureCtrl,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(labelText: 'Startdruck (bar)'),
            ),
            const SizedBox(height: 12),
            FilledButton.icon(
              icon: const Icon(Icons.nfc),
              label: const Text('Scan & Einchecken'),
              onPressed: () async {
                try {
                  setState(()=>_status='Scanne…');
                  final data = await NFCService.readFirefighter();
                  if (data == null) {
                    setState(()=>_status='Kein gültiger Tag/Record gefunden');
                    return;
                  }
                  final id = (data['id'] as String).trim();
                  final name = (data['name'] as String?)?.trim() ?? '';
                  final phone = (data['phone'] as String?)?.trim() ?? '';
                  final emergencyPhone = (data['emergencyPhone'] as String?)?.trim() ?? '';

                  // im Directory speichern
                  app.upsertFirefighter(Firefighter(
                    id: id,
                    name: name,
                    phone: phone,
                    emergencyPhone: emergencyPhone,
                  ));

                  final pressure = int.tryParse(_pressureCtrl.text);
                  if (pressure == null) {
                    setState(()=>_status='Bitte Startdruck (bar) eingeben');
                    return;
                  }

                  final res = app.tryCheckIn(widget.teamId, CheckIn(
                    firefighterId: id,
                    start: DateTime.now(),
                    startPressureBar: pressure,
                  ));

                  switch (res) {
                    case CheckInResult.ok:
                      if (!mounted) return;
                      Navigator.pop(context);
                      break;
                    case CheckInResult.teamFull:
                      await _showWarnDialog('Team voll', 'Dieser Trupp hat bereits 4 Personen.');
                      break;
                    case CheckInResult.alreadyInSameTeam:
                      await _showWarnDialog('Schon im Trupp', '${name.isNotEmpty ? name : id} ist in diesem Trupp bereits eingecheckt.');
                      break;
                    case CheckInResult.alreadyInOtherTeam:
                      final other = app.activeTeamFor(id) ?? 'anderem Trupp';
                      await _showWarnDialog('Bereits im Einsatz', '${name.isNotEmpty ? name : id} ist bereits in $other im Einsatz. Bitte zuerst dort auschecken.');
                      break;
                  }
                } catch (e) {
                  setState(()=>_status='Fehler: $e');
                }
              },
            ),
          ],
        ),
      ),
    );
  }
}

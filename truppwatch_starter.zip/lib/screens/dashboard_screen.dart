import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../app.dart';
import '../widgets/team_card.dart';
import 'team_detail_screen.dart';
import 'nfc_scan_screen.dart';
import 'nfc_program_screen.dart';

class DashboardScreen extends StatelessWidget {
  const DashboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();

    return Scaffold(
      appBar: AppBar(
        title: const Text('TruppWatch – Übersicht'),
        actions: [
          IconButton(
            tooltip: app.keepScreenOn ? 'Einsatzmodus aus' : 'Einsatzmodus an (Bildschirm anlassen)',
            icon: Icon(app.keepScreenOn ? Icons.light_mode : Icons.light_mode_outlined),
            onPressed: () => app.setKeepScreenOn(!app.keepScreenOn),
          ),
        ],
      ),
      body: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: app.teams.length,
        itemBuilder: (_, i) {
          final team = app.teams[i];
          return TeamCard(
            team: team,
            onOpen: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => TeamDetailScreen(teamId: team.id)),
            ),
            onScan: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => NFCScanScreen(teamId: team.id)),
            ),
          );
        },
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => Navigator.push(
          context,
          MaterialPageRoute(builder: (_) => const NFCProgramScreen()),
        ),
        label: const Text('NFC programmieren'),
        icon: const Icon(Icons.badge),
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'services/notification_service.dart';
import 'services/storage_service.dart';
import 'services/event_log_service.dart';
import 'app.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await StorageService.init();
  await NotificationService.init();
  await EventLogService.load();
  runApp(const TruppWatchApp());
}

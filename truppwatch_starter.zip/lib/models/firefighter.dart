class Firefighter {
  final String id; // NFC Tag UID oder generierte ID
  final String name;
  final String phone;
  final String emergencyPhone;

  const Firefighter({
    required this.id,
    required this.name,
    required this.phone,
    required this.emergencyPhone,
  });

  Firefighter copyWith({String? name, String? phone, String? emergencyPhone}) =>
      Firefighter(
        id: id,
        name: name ?? this.name,
        phone: phone ?? this.phone,
        emergencyPhone: emergencyPhone ?? this.emergencyPhone,
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'phone': phone,
        'emergencyPhone': emergencyPhone,
      };

  static Firefighter fromJson(Map<String, dynamic> j) => Firefighter(
        id: j['id'],
        name: j['name'],
        phone: j['phone'] ?? '',
        emergencyPhone: j['emergencyPhone'] ?? '',
      );
}

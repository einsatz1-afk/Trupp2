class CheckIn {
  final String firefighterId;
  final DateTime start;
  final int startPressureBar;
  final DateTime? lastContact; // quittierte Rückmeldung

  CheckIn({
    required this.firefighterId,
    required this.start,
    required this.startPressureBar,
    this.lastContact,
  });

  CheckIn copyWith({DateTime? lastContact}) => CheckIn(
        firefighterId: firefighterId,
        start: start,
        startPressureBar: startPressureBar,
        lastContact: lastContact ?? this.lastContact,
      );

  Map<String, dynamic> toJson() => {
        'firefighterId': firefighterId,
        'start': start.toIso8601String(),
        'startPressureBar': startPressureBar,
        'lastContact': lastContact?.toIso8601String(),
      };

  static CheckIn fromJson(Map<String, dynamic> j) => CheckIn(
        firefighterId: j['firefighterId'],
        start: DateTime.parse(j['start']),
        startPressureBar: j['startPressureBar'],
        lastContact: j['lastContact'] != null
            ? DateTime.parse(j['lastContact'])
            : null,
      );
}

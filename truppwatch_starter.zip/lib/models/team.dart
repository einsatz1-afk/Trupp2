import 'checkin.dart';

class Team {
  final String id; // e.g. "trupp-1"
  final String label; // "Trupp 1"
  final List<CheckIn> members; // aktive Atemschutzträger im Einsatz
  final DateTime createdAt;
  final int contactIntervalMin;

  Team({
    required this.id,
    required this.label,
    required this.members,
    required this.createdAt,
    required this.contactIntervalMin,
  });

  Team copyWith({List<CheckIn>? members, int? contactIntervalMin}) => Team(
        id: id,
        label: label,
        members: members ?? this.members,
        createdAt: createdAt,
        contactIntervalMin: contactIntervalMin ?? this.contactIntervalMin,
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'label': label,
        'members': members.map((m) => m.toJson()).toList(),
        'createdAt': createdAt.toIso8601String(),
        'contactIntervalMin': contactIntervalMin,
      };

  static Team fromJson(Map<String, dynamic> j) => Team(
        id: j['id'],
        label: j['label'],
        members: (j['members'] as List).map((e) => CheckIn.fromJson(e)).toList(),
        createdAt: DateTime.parse(j['createdAt']),
        contactIntervalMin: j['contactIntervalMin'] ?? 10,
      );
}

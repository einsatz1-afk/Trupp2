enum EventType { checkIn, contactAck, checkOut, reminderDue, note }

class EventLogEntry {
  final String id; // einfache ID
  final DateTime ts;
  final String teamId;         // z.B. "trupp-1" oder Label "Trupp 1"
  final EventType type;
  final String? firefighterId;   // technisch (Badge/ID)
  final String? firefighterName; // Anzeige/Name
  final String? message;         // Zusatzinfo (z. B. Startdruck)

  EventLogEntry({
    required this.id,
    required this.ts,
    required this.teamId,
    required this.type,
    this.firefighterId,
    this.firefighterName,
    this.message,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'ts': ts.toIso8601String(),
        'teamId': teamId,
        'type': type.name,
        'firefighterId': firefighterId,
        'firefighterName': firefighterName,
        'message': message,
      };

  static EventLogEntry fromJson(Map<String, dynamic> j) => EventLogEntry(
        id: j['id'],
        ts: DateTime.parse(j['ts']),
        teamId: j['teamId'],
        type: EventType.values.firstWhere(
          (e) => e.name == j['type'],
          orElse: () => EventType.note,
        ),
        firefighterId: j['firefighterId'],
        firefighterName: j['firefighterName'],
        message: j['message'],
      );
}

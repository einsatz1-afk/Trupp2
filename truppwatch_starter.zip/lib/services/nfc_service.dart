import 'dart:convert';
import 'package:flutter_nfc_kit/flutter_nfc_kit.dart';
import 'package:ndef/ndef.dart' as ndef;

class NFCService {
  // Liest NDEF-Text-Record und erwartet JSON mit {id,name,phone,emergencyPhone}
  static Future<Map<String, dynamic>?> readFirefighter() async {
    try {
      final tag = await FlutterNfcKit.poll();
      final records = await FlutterNfcKit.readNDEFRecords();
      await FlutterNfcKit.finish();
      for (final r in records) {
        if (r.typeNameFormat == NDEFTypeNameFormat.nfcWellKnown && r.type == 'T') {
          final rec = ndef.TextRecord.fromBytePayload(r.payload);
          final jsonStr = rec.text;
          return json.decode(jsonStr) as Map<String, dynamic>;
        }
      }
    } catch (e) {
      rethrow;
    }
    return null;
  }

  // Schreibt NDEF Textrecord mit JSON-Daten in UTF-8
  static Future<void> writeFirefighter(Map<String, dynamic> data) async {
    final jsonStr = jsonEncode(data);
    final textRec = ndef.TextRecord(text: jsonStr, language: 'de');
    final ndefRec = NDEFRecord(
      typeNameFormat: NDEFTypeNameFormat.nfcWellKnown,
      type: 'T',
      payload: textRec.toBytePayload(),
    );
    await FlutterNfcKit.poll(timeout: const Duration(seconds: 20));
    await FlutterNfcKit.writeNDEFRecords([ndefRec]);
    await FlutterNfcKit.finish();
  }
}

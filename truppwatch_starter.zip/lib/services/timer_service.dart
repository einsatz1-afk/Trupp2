import 'dart:async';

typedef Tick = void Function(Duration elapsed);

class TimerService {
  final DateTime start;
  final Tick onTick;
  Timer? _timer;

  TimerService({required this.start, required this.onTick});

  void startTicker() {
    _timer?.cancel();
    _timer = Timer.periodic(const Duration(seconds: 1), (_) {
      final elapsed = DateTime.now().difference(start);
      onTick(elapsed);
    });
  }

  void stop() => _timer?.cancel();
}

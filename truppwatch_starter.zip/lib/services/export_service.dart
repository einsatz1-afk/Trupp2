import 'dart:io';
import 'package:csv/csv.dart';
import 'package:share_plus/share_plus.dart';
import 'package:path_provider/path_provider.dart';
import 'event_log_service.dart';
import '../models/event.dart';

class ExportService {
  static Future<String> exportTeamLog({required String teamLabel}) async {
    final events = EventLogService.forTeamLabel(teamLabel);
    final rows = <List<dynamic>>[
      ['Zeit', 'Trupp', 'Ereignis', 'Träger', 'Hinweis'],
      ...events.map((e) => [
            e.ts.toIso8601String(),
            teamLabel,
            _labelFor(e.type),
            (e.firefighterName?.isNotEmpty == true) ? e.firefighterName : (e.firefighterId ?? ''),
            e.message ?? '',
          ])
    ];
    final csv = const ListToCsvConverter().convert(rows);
    final dir = await getTemporaryDirectory();
    final ts = DateTime.now();
    final filename = 'truppwatch_${teamLabel.replaceAll(' ', '_')}_${ts.millisecondsSinceEpoch}.csv';
    final file = File('${dir.path}/$filename');
    await file.writeAsString(csv);
    return file.path;
  }

  static Future<void> shareTeamLog({required String teamLabel}) async {
    final path = await exportTeamLog(teamLabel: teamLabel);
    await Share.shareXFiles([XFile(path)], subject: 'TruppWatch Export $teamLabel');
  }

  static String _labelFor(EventType t) {
    switch (t) {
      case EventType.checkIn: return 'Check-in';
      case EventType.contactAck: return 'Kontakt quittiert';
      case EventType.checkOut: return 'Check-out';
      case EventType.reminderDue: return 'Erinnerung fällig';
      case EventType.note: return 'Notiz';
    }
  }
}

import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/data/latest.dart' as tz;
import 'package:timezone/timezone.dart' as tz;
import '../utils/constants.dart';

class NotificationService {
  static final _plugin = FlutterLocalNotificationsPlugin();

  static Future init() async {
    tz.initializeTimeZones();

    const android = AndroidInitializationSettings('@mipmap/ic_launcher');
    const ios = DarwinInitializationSettings();
    const init = InitializationSettings(android: android, iOS: ios);
    await _plugin.initialize(init);

    const AndroidNotificationChannel channel = AndroidNotificationChannel(
      TW.androidChannelId,
      TW.androidChannelName,
      importance: Importance.max,
      description: 'TruppWatch Alarme & Erinnerungen',
    );
    final androidImpl =
        _plugin.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
    await androidImpl?.createNotificationChannel(channel);
  }

  static NotificationDetails _details() {
    const android = AndroidNotificationDetails(
      TW.androidChannelId,
      TW.androidChannelName,
      importance: Importance.max,
      priority: Priority.high,
      playSound: true,
      enableVibration: true,
      audioAttributesUsage: AudioAttributesUsage.alarm,
    );
    const ios = DarwinNotificationDetails(presentSound: true);
    return const NotificationDetails(android: android, iOS: ios);
  }

  static Future showNow(int id, String title, String body) async {
    await _plugin.show(id, title, body, _details());
  }

  static Future scheduleInMinutes({
    required int id,
    required String title,
    required String body,
    required int minutes,
  }) async {
    await _plugin.zonedSchedule(
      id,
      title,
      body,
      tz.TZDateTime.now(tz.local).add(Duration(minutes: minutes)),
      _details(),
      androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
      uiLocalNotificationDateInterpretation:
          UILocalNotificationDateInterpretation.absoluteTime,
      payload: 'contact',
    );
  }
}

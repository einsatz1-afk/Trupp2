import '../models/event.dart';
import 'storage_service.dart';

class EventLogService {
  static const _key = 'events';
  static List<EventLogEntry> _events = [];

  static Future<void> load() async {
    final map = StorageService.get<Map<String, dynamic>>(_key, (m) => m);
    if (map != null) {
      final list = (map['items'] as List?) ?? [];
      _events = list.map((e) => EventLogEntry.fromJson(Map<String, dynamic>.from(e))).toList();
    }
  }

  static List<EventLogEntry> forTeam(String teamId) {
    final out = _events.where((e) => e.teamId == teamId).toList();
    out.sort((a,b) => a.ts.compareTo(b.ts));
    return out;
  }

  static List<EventLogEntry> forTeamLabel(String teamLabel) => forTeam(teamLabel);

  static Future<void> add(EventLogEntry e) async {
    _events.add(e);
    await StorageService.put(_key, {
      'items': _events.map((x) => x.toJson()).toList(),
    });
  }
}

import 'dart:convert';
import 'package:hive_flutter/hive_flutter.dart';

class StorageService {
  static const _boxName = 'truppwatch';
  static late Box _box;

  static Future init() async {
    await Hive.initFlutter();
    _box = await Hive.openBox(_boxName);
  }

  static Future<void> put(String key, Object value) async {
    await _box.put(key, jsonEncode(value));
  }

  static T? get<T>(String key, T Function(Map<String, dynamic>) fromJson) {
    final s = _box.get(key);
    if (s == null) return null;
    return fromJson(jsonDecode(s));
  }
}

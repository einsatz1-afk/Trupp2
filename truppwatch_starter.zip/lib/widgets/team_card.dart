import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/team.dart';
import '../app.dart';

class TeamCard extends StatelessWidget {
  final Team team;
  final VoidCallback onOpen;
  final VoidCallback onScan;

  const TeamCard({super.key, required this.team, required this.onOpen, required this.onScan});

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    return Card(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Text(team.label, style: Theme.of(context).textTheme.titleLarge),
                const Spacer(),
                FilledButton.icon(onPressed: onScan, icon: const Icon(Icons.nfc), label: const Text('NFC')),
                const SizedBox(width: 8),
                OutlinedButton(onPressed: onOpen, child: const Text('Details')),
              ],
            ),
            const SizedBox(height: 12),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: team.members.map((m) => Chip(label: Text(app.displayNameFor(m.firefighterId)))).toList(),
            )
          ],
        ),
      ),
    );
  }
}

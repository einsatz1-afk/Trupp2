import 'package:flutter/material.dart';

class FirefighterChip extends StatelessWidget {
  final String name;
  final int startPressure;
  final Duration elapsed;
  final DateTime? lastContact;
  final DateTime dueAt;
  final bool overdue;
  final VoidCallback onTap;      // Kontakt quittieren
  final VoidCallback onCheckout; // Einsatz beenden

  const FirefighterChip({
    super.key,
    required this.name,
    required this.startPressure,
    required this.elapsed,
    required this.lastContact,
    required this.dueAt,
    required this.overdue,
    required this.onTap,
    required this.onCheckout,
  });

  @override
  Widget build(BuildContext context) {
    final now = DateTime.now();
    final until = dueAt.difference(now);
    final untilStr = overdue
        ? 'überfällig seit ${until.abs().inMinutes}m'
        : 'in ${until.inMinutes}m ${until.inSeconds % 60}s';

    return Card(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: InkWell(
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Row(
            children: [
              Icon(Icons.person, size: 28, color: overdue ? Colors.red : null),
              const SizedBox(width: 8),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(name, style: Theme.of(context).textTheme.titleMedium),
                    const SizedBox(height:4),
                    Text('Einsatz: ${elapsed.inMinutes}m ${elapsed.inSeconds % 60}s · Startdruck: $startPressure bar'),
                    Text('Nächster Kontakt: ${dueAt.hour.toString().padLeft(2,'0')}:${dueAt.minute.toString().padLeft(2,'0')} · $untilStr'),
                    if (lastContact != null) Text('Letzter Kontakt: $lastContact'),
                  ],
                ),
              ),
              if (overdue) const Icon(Icons.warning_amber, size: 20, color: Colors.red),
              IconButton(icon: const Icon(Icons.logout), onPressed: onCheckout),
            ],
          ),
        ),
      ),
    );
  }
}

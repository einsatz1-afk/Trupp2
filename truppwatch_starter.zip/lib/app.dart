import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'models/team.dart';
import 'models/checkin.dart';
import 'models/event.dart';
import 'models/firefighter.dart';
import 'services/storage_service.dart';
import 'services/notification_service.dart';
import 'services/event_log_service.dart';
import 'package:wakelock_plus/wakelock_plus.dart';
import 'screens/dashboard_screen.dart';

enum CheckInResult { ok, teamFull, alreadyInSameTeam, alreadyInOtherTeam }

class AppState extends ChangeNotifier {
  final Map<String, Team> _teams = {};
  final Map<String, Firefighter> _people = {}; // id -> Firefighter
  bool _keepScreenOn = false;

  List<Team> get teams => _teams.values.toList()..sort((a,b)=>a.id.compareTo(b.id));
  bool get keepScreenOn => _keepScreenOn;

  // --- Firefighter Directory ---
  void upsertFirefighter(Firefighter f) {
    _people[f.id] = f;
    persist();
    notifyListeners();
  }

  String displayNameFor(String firefighterId) {
    final f = _people[firefighterId];
    return f?.name.isNotEmpty == true ? f!.name : firefighterId;
  }

  Firefighter? firefighterById(String id) => _people[id];

  // --- Teams ---
  void initDefaultTeams(int count) {
    for (var i = 1; i <= count; i++) {
      final id = 'trupp-$i';
      _teams[id] = Team(
        id: id,
        label: 'Trupp $i',
        members: [],
        createdAt: DateTime.now(),
        contactIntervalMin: 10,
      );
    }
    notifyListeners();
  }

  Future setKeepScreenOn(bool v) async {
    _keepScreenOn = v;
    if (v) {
      await WakelockPlus.enable();
    } else {
      await WakelockPlus.disable();
    }
    notifyListeners();
  }

  void setContactInterval(String teamId, int minutes) {
    final t = _teams[teamId];
    if (t == null) return;
    _teams[teamId] = t.copyWith(contactIntervalMin: minutes);
    notifyListeners();
  }

  // Helper: prüft, ob ID bereits in einem Team aktiv ist und liefert ggf. das Team-Label
  String? activeTeamFor(String firefighterId) {
    for (final t in _teams.values) {
      if (t.members.any((m) => m.firefighterId == firefighterId)) return t.label;
    }
    return null;
  }

  // Sicherer Check‑in: Doppel-Check + sofortiges Logging & Notification-Planung
  CheckInResult tryCheckIn(String teamId, CheckIn c) {
    final t = _teams[teamId];
    if (t == null) return CheckInResult.alreadyInOtherTeam; // fail‑safe

    if (t.members.length >= 4) return CheckInResult.teamFull;
    if (t.members.any((m) => m.firefighterId == c.firefighterId)) {
      return CheckInResult.alreadyInSameTeam;
    }
    final other = activeTeamFor(c.firefighterId);
    if (other != null) return CheckInResult.alreadyInOtherTeam;

    // OK → Mitglied aufnehmen
    _teams[teamId] = t.copyWith(members: [...t.members, c]);

    final name = displayNameFor(c.firefighterId);

    // Ereignislog schreiben
    EventLogService.add(EventLogEntry(
      id: DateTime.now().microsecondsSinceEpoch.toString(),
      ts: DateTime.now(),
      teamId: teamId,
      type: EventType.checkIn,
      firefighterId: c.firefighterId,
      firefighterName: name,
      message: 'Startdruck: ${c.startPressureBar} bar',
    ));

    // Ersten Kontakt-Reminder planen
    NotificationService.scheduleInMinutes(
      id: 100 + c.firefighterId.hashCode % 100,
      title: _teams[teamId]!.label,
      body: 'Kontakt fällig für $name',
      minutes: _teams[teamId]!.contactIntervalMin,
    );

    persist();
    notifyListeners();
    return CheckInResult.ok;
  }

  // Kontakt quittiert → Log + nächsten Reminder
  void contactAck(String teamId, String firefighterId, DateTime ts) {
    final t = _teams[teamId];
    if (t == null) return;
    final updated = t.members.map((m) =>
        m.firefighterId == firefighterId ? m.copyWith(lastContact: ts) : m
      ).toList();
    _teams[teamId] = t.copyWith(members: updated);

    final name = displayNameFor(firefighterId);

    EventLogService.add(EventLogEntry(
      id: DateTime.now().microsecondsSinceEpoch.toString(),
      ts: ts,
      teamId: teamId,
      type: EventType.contactAck,
      firefighterId: firefighterId,
      firefighterName: name,
      message: 'Kontakt quittiert',
    ));

    NotificationService.scheduleInMinutes(
      id: 100 + firefighterId.hashCode % 100,
      title: _teams[teamId]!.label,
      body: 'Kontakt fällig für $name',
      minutes: _teams[teamId]!.contactIntervalMin,
    );

    persist();
    notifyListeners();
  }

  // Check‑out → Log schreiben
  void checkOut(String teamId, String firefighterId) {
    final t = _teams[teamId];
    if (t == null) return;
    _teams[teamId] = t.copyWith(
      members: t.members.where((m) => m.firefighterId != firefighterId).toList(),
    );

    final name = displayNameFor(firefighterId);

    EventLogService.add(EventLogEntry(
      id: DateTime.now().microsecondsSinceEpoch.toString(),
      ts: DateTime.now(),
      teamId: teamId,
      type: EventType.checkOut,
      firefighterId: firefighterId,
      firefighterName: name,
      message: 'Check-out',
    ));

    persist();
    notifyListeners();
  }

  void persist() {
    StorageService.put('teams', {
      'items': _teams.map((k, v) => MapEntry(k, v.toJson()))
    });
    StorageService.put('people', {
      'items': _people.map((k, v) => MapEntry(k, v.toJson()))
    });
  }
}

class TruppWatchApp extends StatelessWidget {
  const TruppWatchApp({super.key});
  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (_) => AppState()..initDefaultTeams(6),
      child: MaterialApp(
        title: 'TruppWatch',
        theme: ThemeData(
          colorScheme: ColorScheme.fromSeed(seedColor: Colors.red),
          useMaterial3: true,
        ),
        home: const DashboardScreen(),
      ),
    );
  }
}

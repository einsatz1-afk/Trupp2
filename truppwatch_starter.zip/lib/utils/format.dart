import 'package:intl/intl.dart';

final _time = DateFormat('HH:mm:ss');
String fmtTime(DateTime dt) => _time.format(dt);
String fmtMins(int mins) => '${mins.toString()} min';
String fmtDuration(Duration d) {
  final m = d.inMinutes;
  final s = d.inSeconds % 60;
  return '${m}m ${s}s';
}

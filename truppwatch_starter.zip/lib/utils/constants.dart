class TW {
  static const appName = 'TruppWatch';
  static const defaultContactIntervalMin = 10; // Standard Schweiz
  static const maxTeamSize = 4;
  static const androidChannelId = 'truppwatch_alarm';
  static const androidChannelName = 'Alarme';
}

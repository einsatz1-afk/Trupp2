# TruppWatch (Flutter)

Atemschutz-Truppüberwachung für Feuerwehr (CH) – NFC, Timer, Logbuch, CSV-Export.

## Build ohne PC (GitHub Actions)
1. Dieses Repo nach GitHub hochladen (als Root eines Flutter-Projekts).
2. Actions laufen lassen (Workflow in `.github/workflows/android-debug.yml`).
3. Artifact `app-debug.apk` herunterladen und auf dem Android-Tablet installieren.

> Der Workflow erstellt fehlende `android/`-Ordner via `flutter create .` automatisch.
